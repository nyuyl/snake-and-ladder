var num=1;
var a=0;
var a1=0;
var a2=0;
var degree= 720;
var s =document.getElementById("move");
function reset()
{
  document.getElementById("divs").style.visibility = "visible";
  document.getElementById("divs").style.backgroundImage = "url('https://s-media-cache-ak0.pinimg.com/736x/c7/26/91/c726918f09cec1bd7c1dcb22f6adf273.jpg')";
   document.getElementById("move").style.visibility = "visible";
  num=1;
  var s=document.getElementById("move");
  var element=document.getElementById("move");
  document.getElementById("a"+num).appendChild(s);
 

      
}
  

function start(){
  
  
  var dice=["","&#9856","&#9857","&#9858","&#9859","&#9860","&#9861"]
   document.getElementById("btn").innerHTML=dice[1];
  document.getElementById("divs").innerHTML="";
  
  var id=100;
  for(k=0;k<5;k++)
    {
for (i=1;i<=10;i++)
  { 
document.getElementById("divs").innerHTML+="<div id='a"+id+"' style='height:49.3px;width:49.5px;float:left;z-index:1'></div>"
    id--;
 }
  for (j=0;j<=9;j++)
  { 
document.getElementById("divs").innerHTML+="<div id='a"+id+"' style='height:50px;width:49.5px;float:right;z-index:1'></div>"
    id--;
 
     
  }   
    
  
}
   document.getElementById("a"+num).appendChild(s);
}
 
function random()
{
  
   let a= Math.ceil(Math.random()*6);
   a1=a;
   document.getElementById("btn").innerHTML=a;
   var dice=["","&#9856","&#9857","&#9858","&#9859","&#9860","&#9861"];
   document.getElementById("btn").innerHTML=dice[a];
    document.getElementById("btn").style.transform = "rotate("+degree+"deg)";
   var s =document.getElementById("move");
  degree+=360;
 
 
  if((num+a)<=100){
    num=num+a;
    num=num-a;
    a2=1;
 
    interval = setInterval(function(){
    num++;
    document.getElementById("a"+num).appendChild(s);
      
if(a2==a1){
     
    if( num==8 || num==15 || num==42 || num==66 || num==24 || num==55 || num==71 || num==88 ||num==99){
     
      a=0;

      if(num==8)
        {
         num=31;
        }
      if(num==15)
        {
         num=97;
        }
      if(num==42)
        {
        num=81;
        }
      if(num==66)
        {
        num=87;
        }
    

      if(num==24)
        {
         num=1;
        }
      if(num==55)
        {
         num=13;
        }
      if(num==71)
        {
         num=29;
        }
      if(num==88)
        {
         num=67;
        }
      if(num==99)
        {
         num=6;
          }
      document.getElementById("a"+num).appendChild(s); 
      document.getElementById("btn").style.visibility = "visible";
       clearInterval(interval);  
  }
     else
       {
         
       
 clearInterval(interval);
     a1=0;
     a2=0;
         if(num==100)
           {
             document.getElementById("btn").style.visibility = "hidden";
             document.getElementById("move").style.visibility = "hidden";
             document.getElementById("divs").style.backgroundImage = "url('http://bit.ly/2tjbLJz')";
             
            
            }
    
     document.getElementById("btn").style.visibility = "visible";
       }
   }
      a2++;
      
     
   },200);
  }
    
 else
        {
          
       
  document.getElementById("a"+num).appendChild(s);
   document.getElementById("btn").style.visibility = "visible";
   
        }
  
  
  
}











